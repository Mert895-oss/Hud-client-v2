package dev.hudclient.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.hudclient.HudClient;
import dev.hudclient.module.Module;
import dev.hudclient.module.ModuleManager;
import dev.hudclient.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private Config() {
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("hud-client.json");
    }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : ModuleManager.all()) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.isEnabled() && m.persistEnabled());
                o.addProperty("key", m.getKey());
                JsonObject s = new JsonObject();
                for (Setting<?> setting : m.getSettings()) {
                    s.add(setting.name, setting.save());
                }
                o.add("settings", s);
                root.add(m.getName(), o);
            }
            Files.writeString(file(), GSON.toJson(root));
        } catch (Exception e) {
            HudClient.LOGGER.error("Could not save config", e);
        }
    }

    public static void load() {
        Path path = file();
        if (!Files.exists(path)) {
            return;
        }
        try {
            JsonObject root = JsonParser.parseString(Files.readString(path)).getAsJsonObject();
            for (Module m : ModuleManager.all()) {
                JsonElement me = root.get(m.getName());
                if (me == null || !me.isJsonObject()) {
                    continue;
                }
                JsonObject o = me.getAsJsonObject();
                if (o.has("key")) {
                    m.setKey(o.get("key").getAsInt());
                }
                if (o.has("settings") && o.get("settings").isJsonObject()) {
                    JsonObject s = o.getAsJsonObject("settings");
                    for (Setting<?> setting : m.getSettings()) {
                        setting.load(s.get(setting.name));
                    }
                }
                if (o.has("enabled")) {
                    m.setEnabled(o.get("enabled").getAsBoolean());
                }
            }
        } catch (Exception e) {
            HudClient.LOGGER.error("Could not load config", e);
        }
    }
}
