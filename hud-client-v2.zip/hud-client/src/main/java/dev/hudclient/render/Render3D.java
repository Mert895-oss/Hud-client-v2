package dev.hudclient.render;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexFormat;
import dev.hudclient.HudClient;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MappableRingBuffer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.util.OptionalDouble;
import java.util.OptionalInt;

/**
 * Batched through-walls renderer (filled quads only). Lines are drawn as thin camera-facing quads.
 * Based on the Fabric docs "Rendering in the World" custom pipeline example for 1.21.11.
 * Usage per frame: begin(ctx) -> box()/outline()/line() calls -> end().
 */
public final class Render3D {
    private static final RenderPipeline PIPELINE = RenderPipelines.register(
            RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
                    .withLocation(Identifier.fromNamespaceAndPath(HudClient.MOD_ID, "pipeline/esp_through_walls"))
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .withCull(false)
                    .build()
    );

    private static final ByteBufferBuilder ALLOCATOR = new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
    private static final Vector4f COLOR_MODULATOR = new Vector4f(1f, 1f, 1f, 1f);
    private static final Vector3f MODEL_OFFSET = new Vector3f();
    private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();

    private static BufferBuilder buffer;
    private static MappableRingBuffer vertexBuffer;
    private static Matrix4fc pose;
    private static double camX;
    private static double camY;
    private static double camZ;

    /** Copy of the world view matrix of the last frame (used to project world points to the screen). */
    public static final Matrix4f VIEW = new Matrix4f();

    private Render3D() {
    }

    // ------------------------------------------------------------------ frame control

    public static void begin(WorldRenderContext context) {
        PoseStack matrices = context.matrices();
        pose = matrices.last().pose();
        VIEW.set(pose);
        Vec3 cam = context.worldState().cameraRenderState.pos;
        camX = cam.x;
        camY = cam.y;
        camZ = cam.z;
        buffer = null;
    }

    public static void end() {
        if (buffer == null) {
            return;
        }
        BufferBuilder builder = buffer;
        buffer = null;

        Minecraft client = Minecraft.getInstance();
        MeshData builtBuffer = builder.buildOrThrow();
        MeshData.DrawState drawParameters = builtBuffer.drawState();
        VertexFormat format = drawParameters.format();

        GpuBuffer vertices = upload(drawParameters, format, builtBuffer);
        draw(client, PIPELINE, builtBuffer, drawParameters, vertices, format);

        vertexBuffer.rotate();
    }

    public static double camX() {
        return camX;
    }

    public static double camY() {
        return camY;
    }

    public static double camZ() {
        return camZ;
    }

    /** Start point for tracers: a little in front of the camera, in its view direction. */
    public static Vec3 tracerOrigin() {
        Matrix4f inv = new Matrix4f(VIEW).invert();
        Vector3f f = new Vector3f(0f, 0f, -1f);
        inv.transformDirection(f);
        return new Vec3(camX + f.x * 0.6, camY + f.y * 0.6, camZ + f.z * 0.6);
    }

    public static void close() {
        ALLOCATOR.close();
        if (vertexBuffer != null) {
            vertexBuffer.close();
            vertexBuffer = null;
        }
    }

    // ------------------------------------------------------------------ public drawing API

    public static void box(AABB b, int argb) {
        box(b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, argb);
    }

    public static void box(double x0, double y0, double z0, double x1, double y1, double z1, int argb) {
        float a = (argb >>> 24 & 255) / 255f;
        float r = (argb >>> 16 & 255) / 255f;
        float g = (argb >>> 8 & 255) / 255f;
        float bl = (argb & 255) / 255f;

        // front (z1)
        v(x0, y0, z1, r, g, bl, a);
        v(x1, y0, z1, r, g, bl, a);
        v(x1, y1, z1, r, g, bl, a);
        v(x0, y1, z1, r, g, bl, a);
        // back (z0)
        v(x1, y0, z0, r, g, bl, a);
        v(x0, y0, z0, r, g, bl, a);
        v(x0, y1, z0, r, g, bl, a);
        v(x1, y1, z0, r, g, bl, a);
        // left (x0)
        v(x0, y0, z0, r, g, bl, a);
        v(x0, y0, z1, r, g, bl, a);
        v(x0, y1, z1, r, g, bl, a);
        v(x0, y1, z0, r, g, bl, a);
        // right (x1)
        v(x1, y0, z1, r, g, bl, a);
        v(x1, y0, z0, r, g, bl, a);
        v(x1, y1, z0, r, g, bl, a);
        v(x1, y1, z1, r, g, bl, a);
        // top (y1)
        v(x0, y1, z1, r, g, bl, a);
        v(x1, y1, z1, r, g, bl, a);
        v(x1, y1, z0, r, g, bl, a);
        v(x0, y1, z0, r, g, bl, a);
        // bottom (y0)
        v(x0, y0, z0, r, g, bl, a);
        v(x1, y0, z0, r, g, bl, a);
        v(x1, y0, z1, r, g, bl, a);
        v(x0, y0, z1, r, g, bl, a);
    }

    public static void outline(AABB b, double width, int argb) {
        double x0 = b.minX, y0 = b.minY, z0 = b.minZ, x1 = b.maxX, y1 = b.maxY, z1 = b.maxZ;
        // bottom
        line(x0, y0, z0, x1, y0, z0, width, argb);
        line(x1, y0, z0, x1, y0, z1, width, argb);
        line(x1, y0, z1, x0, y0, z1, width, argb);
        line(x0, y0, z1, x0, y0, z0, width, argb);
        // top
        line(x0, y1, z0, x1, y1, z0, width, argb);
        line(x1, y1, z0, x1, y1, z1, width, argb);
        line(x1, y1, z1, x0, y1, z1, width, argb);
        line(x0, y1, z1, x0, y1, z0, width, argb);
        // pillars
        line(x0, y0, z0, x0, y1, z0, width, argb);
        line(x1, y0, z0, x1, y1, z0, width, argb);
        line(x1, y0, z1, x1, y1, z1, width, argb);
        line(x0, y0, z1, x0, y1, z1, width, argb);
    }

    public static void line(Vec3 a, Vec3 b, double width, int argb) {
        line(a.x, a.y, a.z, b.x, b.y, b.z, width, argb);
    }

    /** Draws a camera-facing quad between two world points. Width grows a little with distance. */
    public static void line(double ax, double ay, double az, double bx, double by, double bz, double width, int argb) {
        double dx = bx - ax;
        double dy = by - ay;
        double dz = bz - az;

        // vector from camera to the segment middle
        double mx = (ax + bx) * 0.5 - camX;
        double my = (ay + by) * 0.5 - camY;
        double mz = (az + bz) * 0.5 - camZ;

        // perpendicular to both the segment and the view direction
        double px = dy * mz - dz * my;
        double py = dz * mx - dx * mz;
        double pz = dx * my - dy * mx;
        double len = Math.sqrt(px * px + py * py + pz * pz);
        if (len < 1.0E-9) {
            return;
        }

        double dist = Math.sqrt(mx * mx + my * my + mz * mz);
        double half = width * Math.max(1.0, dist / 20.0) * 0.5;
        double s = half / len;
        px *= s;
        py *= s;
        pz *= s;

        float a = (argb >>> 24 & 255) / 255f;
        float r = (argb >>> 16 & 255) / 255f;
        float g = (argb >>> 8 & 255) / 255f;
        float bl = (argb & 255) / 255f;

        v(ax + px, ay + py, az + pz, r, g, bl, a);
        v(bx + px, by + py, bz + pz, r, g, bl, a);
        v(bx - px, by - py, bz - pz, r, g, bl, a);
        v(ax - px, ay - py, az - pz, r, g, bl, a);
    }

    // ------------------------------------------------------------------ internals

    private static void v(double x, double y, double z, float r, float g, float b, float a) {
        if (buffer == null) {
            buffer = new BufferBuilder(ALLOCATOR, PIPELINE.getVertexFormatMode(), PIPELINE.getVertexFormat());
        }
        buffer.addVertex(pose, (float) (x - camX), (float) (y - camY), (float) (z - camZ)).setColor(r, g, b, a);
    }

    private static GpuBuffer upload(MeshData.DrawState drawParameters, VertexFormat format, MeshData builtBuffer) {
        int vertexBufferSize = drawParameters.vertexCount() * format.getVertexSize();

        if (vertexBuffer == null || vertexBuffer.size() < vertexBufferSize) {
            if (vertexBuffer != null) {
                vertexBuffer.close();
            }
            vertexBuffer = new MappableRingBuffer(() -> HudClient.MOD_ID + " esp vertex buffer", GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE, vertexBufferSize);
        }

        CommandEncoder commandEncoder = RenderSystem.getDevice().createCommandEncoder();

        try (GpuBuffer.MappedView mappedView = commandEncoder.mapBuffer(vertexBuffer.currentBuffer().slice(0, builtBuffer.vertexBuffer().remaining()), false, true)) {
            MemoryUtil.memCopy(builtBuffer.vertexBuffer(), mappedView.data());
        }

        return vertexBuffer.currentBuffer();
    }

    private static void draw(Minecraft client, RenderPipeline pipeline, MeshData builtBuffer, MeshData.DrawState drawParameters, GpuBuffer vertices, VertexFormat format) {
        GpuBuffer indices;
        VertexFormat.IndexType indexType;

        if (pipeline.getVertexFormatMode() == VertexFormat.Mode.QUADS) {
            builtBuffer.sortQuads(ALLOCATOR, RenderSystem.getProjectionType().vertexSorting());
            indices = pipeline.getVertexFormat().uploadImmediateIndexBuffer(builtBuffer.indexBuffer());
            indexType = builtBuffer.drawState().indexType();
        } else {
            RenderSystem.AutoStorageIndexBuffer shapeIndexBuffer = RenderSystem.getSequentialBuffer(pipeline.getVertexFormatMode());
            indices = shapeIndexBuffer.getBuffer(drawParameters.indexCount());
            indexType = shapeIndexBuffer.type();
        }

        GpuBufferSlice dynamicTransforms = RenderSystem.getDynamicUniforms()
                .writeTransform(RenderSystem.getModelViewMatrix(), COLOR_MODULATOR, MODEL_OFFSET, TEXTURE_MATRIX);

        try (RenderPass renderPass = RenderSystem.getDevice()
                .createCommandEncoder()
                .createRenderPass(() -> HudClient.MOD_ID + " esp render pass", client.getMainRenderTarget().getColorTextureView(), OptionalInt.empty(), client.getMainRenderTarget().getDepthTextureView(), OptionalDouble.empty())) {
            renderPass.setPipeline(pipeline);

            RenderSystem.bindDefaultUniforms(renderPass);
            renderPass.setUniform("DynamicTransforms", dynamicTransforms);

            renderPass.setVertexBuffer(0, vertices);
            renderPass.setIndexBuffer(indices, indexType);

            renderPass.drawIndexed(0, 0, drawParameters.indexCount(), 1);
        }

        builtBuffer.close();
    }
}
