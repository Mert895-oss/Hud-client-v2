package dev.hudclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Marker;
import net.minecraft.world.phys.Vec3;

/**
 * Shared camera trick for Freecam / Freelook: a client-only marker entity (never added to the world)
 * is used as the camera entity, and we place and rotate it ourselves every frame.
 */
public final class CameraController {
    private static Marker fake;

    private CameraController() {
    }

    private static Marker ensure(Minecraft mc) {
        if (mc.level == null) {
            return null;
        }
        if (fake == null || fake.level() != mc.level) {
            fake = new Marker(EntityType.MARKER, mc.level);
        }
        return fake;
    }

    /** Puts the camera at the given eye position with the given rotation. */
    public static void apply(Minecraft mc, double x, double y, double z, float yaw, float pitch) {
        Marker e = ensure(mc);
        if (e == null) {
            return;
        }
        e.setPos(x, y, z);
        e.xo = x;
        e.yo = y;
        e.zo = z;
        e.setYRot(yaw);
        e.setXRot(pitch);
        e.yRotO = yaw;
        e.xRotO = pitch;
        if (mc.getCameraEntity() != e) {
            mc.setCameraEntity(e);
        }
    }

    /** Gives the camera back to the player. */
    public static void release(Minecraft mc) {
        if (mc.player != null && fake != null && mc.getCameraEntity() == fake) {
            mc.setCameraEntity(mc.player);
        }
        fake = null;
    }

    /**
     * Reads how far the mouse turned the player this frame and puts the player's rotation back,
     * so the real player keeps looking the same way. Returns {yawDelta, pitchDelta}.
     */
    public static float[] takeMouseDelta(Minecraft mc, float frozenYaw, float frozenPitch) {
        LocalPlayer p = mc.player;
        float dy = p.getYRot() - frozenYaw;
        float dp = p.getXRot() - frozenPitch;
        p.setYRot(frozenYaw);
        p.setXRot(frozenPitch);
        p.yRotO = frozenYaw;
        p.xRotO = frozenPitch;
        return new float[]{dy, dp};
    }

    /** Where tracer lines start: a bit in front of whatever the camera currently is. */
    public static Vec3 tracerOrigin(Minecraft mc, float partialTick) {
        Entity cam = mc.getCameraEntity() != null ? mc.getCameraEntity() : mc.player;
        return cam.getEyePosition(partialTick).add(cam.getViewVector(partialTick).scale(0.6));
    }
}
