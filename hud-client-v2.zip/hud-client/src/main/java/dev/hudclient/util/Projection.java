package dev.hudclient.util;

import dev.hudclient.render.Render3D;
import net.minecraft.client.Minecraft;
import org.joml.Vector3f;

/** Projects world positions to GUI-scaled screen coordinates (approximate: uses the FOV option). */
public final class Projection {
    private static final Vector3f TMP = new Vector3f();

    private Projection() {
    }

    /** Returns {x, y} in GUI coordinates, or null if the point is behind the camera. */
    public static double[] toScreen(double wx, double wy, double wz) {
        Minecraft mc = Minecraft.getInstance();
        TMP.set((float) (wx - Render3D.camX()), (float) (wy - Render3D.camY()), (float) (wz - Render3D.camZ()));
        Render3D.VIEW.transformPosition(TMP);
        if (TMP.z >= -0.05f) {
            return null;
        }
        double fov = mc.options.fov().get();
        double tan = Math.tan(Math.toRadians(fov) / 2.0);
        double aspect = (double) mc.getWindow().getWidth() / (double) mc.getWindow().getHeight();
        double ndcX = (TMP.x / -TMP.z) / (tan * aspect);
        double ndcY = (TMP.y / -TMP.z) / tan;
        double sx = (ndcX * 0.5 + 0.5) * mc.getWindow().getGuiScaledWidth();
        double sy = (0.5 - ndcY * 0.5) * mc.getWindow().getGuiScaledHeight();
        return new double[]{sx, sy};
    }
}
