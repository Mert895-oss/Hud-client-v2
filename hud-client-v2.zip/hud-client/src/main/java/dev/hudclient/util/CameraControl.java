package dev.hudclient.util;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

/** Shared state for Freecam and Freelook. The camera mixin reads this every frame. */
public final class CameraControl {
    public static boolean freecam;
    public static boolean freelook;
    public static float yaw;
    public static float pitch;
    public static double x;
    public static double y;
    public static double z;
    public static double px;
    public static double py;
    public static double pz;
    public static double distance = 4.0;

    private static CameraType saved;

    private CameraControl() {
    }

    public static boolean active() {
        return freecam || freelook;
    }

    public static void start(Minecraft mc, boolean free) {
        if (mc.player == null) {
            return;
        }
        if (!active()) {
            saved = mc.options.getCameraType();
            mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
            yaw = mc.player.getYRot();
            pitch = mc.player.getXRot();
            // vanilla cave culling would hide chunks while the camera is inside walls
            mc.smartCull = false;
        }
        if (free) {
            Vec3 eye = mc.player.getEyePosition();
            x = eye.x;
            y = eye.y;
            z = eye.z;
            px = x;
            py = y;
            pz = z;
            freecam = true;
        } else {
            freelook = true;
        }
    }

    public static void stop(Minecraft mc, boolean free) {
        if (free) {
            freecam = false;
        } else {
            freelook = false;
        }
        if (!active()) {
            mc.options.setCameraType(saved == null ? CameraType.FIRST_PERSON : saved);
            mc.smartCull = true;
        }
    }
}
