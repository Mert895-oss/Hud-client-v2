package dev.hudclient.gui;

import dev.hudclient.config.Config;
import dev.hudclient.HudClient;
import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.module.ModuleManager;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.ListSetting;
import dev.hudclient.setting.ModeSetting;
import dev.hudclient.setting.NumberSetting;
import dev.hudclient.setting.Setting;
import dev.hudclient.setting.TextSetting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * HUD v2 click GUI: category sidebar on the left, animated module cards on the right.
 * Left click  = module on/off
 * Right click = settings page of that module (right click anywhere / back arrow = return)
 * Middle click = bind a key (press a key; ESC clears the bind)
 */
public class ClickGuiScreen extends Screen {
    private static final int HDR = 22;
    private static final int SIDE = 90;
    private static final int ROW = 15;
    private static final int PURPLE = 0xA855F7;

    private Category cat = Category.values()[0];
    private Module open;
    private Module binding;
    private NumberSetting dragging;
    private int dragX0;
    private int dragX1;
    private float fade = 0.2f;

    private final Map<Module, float[]> anim = new HashMap<>();
    private final Map<Category, float[]> catAnim = new HashMap<>();

    // window geometry
    private int wx;
    private int wy;
    private int ww;
    private int wh;

    public ClickGuiScreen() {
        super(Component.literal("HUD"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        Config.save();
        super.onClose();
    }

    // ------------------------------------------------------------------ small helpers

    private void geom() {
        ww = Math.min(this.width - 10, 470);
        wh = Math.min(this.height - 10, 290);
        wx = (this.width - ww) / 2;
        wy = (this.height - wh) / 2;
    }

    private int fa(int argb) {
        int al = (int) (((argb >>> 24) & 255) * fade);
        return (Math.max(al, 4) << 24) | (argb & 0xFFFFFF);
    }

    private static int lerp(int c1, int c2, float t) {
        int a = (int) (((c1 >>> 24) & 255) + (((c2 >>> 24) & 255) - ((c1 >>> 24) & 255)) * t);
        int r = (int) (((c1 >> 16) & 255) + (((c2 >> 16) & 255) - ((c1 >> 16) & 255)) * t);
        int g = (int) (((c1 >> 8) & 255) + (((c2 >> 8) & 255) - ((c1 >> 8) & 255)) * t);
        int b = (int) ((c1 & 255) + ((c2 & 255) - (c1 & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Rectangle with 1px cut corners. */
    private void rrect(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x + 1, y, x + w - 1, y + h, color);
        g.fill(x, y + 1, x + w, y + h - 1, color);
    }

    private void gradBar(GuiGraphics g, int x, int y, int w, int h, int c1, int c2) {
        int n = Math.max(1, w / 3);
        for (int i = 0; i < n; i++) {
            int x0 = x + i * w / n;
            int x1 = x + (i + 1) * w / n;
            g.fill(x0, y, x1, y + h, fa(lerp(0xFF000000 | c1, 0xFF000000 | c2, i / (float) n)));
        }
    }

    private static List<Module> modulesOf(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : ModuleManager.all()) {
            if (m.category == c) {
                out.add(m);
            }
        }
        return out;
    }

    private static String keyName(int key) {
        if (key < 0) {
            return "";
        }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) return "RSHIFT";
        if (key == GLFW.GLFW_KEY_LEFT_SHIFT) return "LSHIFT";
        if (key == GLFW.GLFW_KEY_RIGHT_CONTROL) return "RCTRL";
        if (key == GLFW.GLFW_KEY_LEFT_CONTROL) return "LCTRL";
        if (key == GLFW.GLFW_KEY_RIGHT_ALT) return "RALT";
        if (key == GLFW.GLFW_KEY_LEFT_ALT) return "LALT";
        if (key == GLFW.GLFW_KEY_SPACE) return "SPACE";
        if (key == GLFW.GLFW_KEY_TAB) return "TAB";
        String n = GLFW.glfwGetKeyName(key, 0);
        return n != null ? n.toUpperCase(Locale.ROOT) : "K" + key;
    }

    // content area (right of the sidebar)
    private int cx() {
        return wx + SIDE;
    }

    private int cy() {
        return wy + HDR;
    }

    private int cw() {
        return ww - SIDE;
    }

    private int ch() {
        return wh - HDR;
    }

    // module card grid
    private int cols() {
        return cw() >= 300 ? 2 : 1;
    }

    private int cardW() {
        return (cw() - 8 * (cols() + 1)) / cols();
    }

    private static final int CARD_H = 24;

    private int cardX(int i) {
        return cx() + 8 + (i % cols()) * (cardW() + 8);
    }

    private int cardY(int i) {
        return cy() + 8 + (i / cols()) * (CARD_H + 6);
    }

    // settings page layout
    private int setCols;
    private int rowsPerCol;
    private int setW;

    private void settingsLayout() {
        int rows = Math.max(1, open.getSettings().size());
        int maxRows = Math.max(3, (ch() - 34) / ROW);
        setCols = (rows + maxRows - 1) / maxRows;
        rowsPerCol = (rows + setCols - 1) / setCols;
        setW = (cw() - 16 - (setCols - 1) * 6) / setCols;
    }

    private int rowX(int i) {
        return cx() + 8 + (i / rowsPerCol) * (setW + 6);
    }

    private int rowY(int i) {
        return cy() + 26 + (i % rowsPerCol) * ROW;
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);
        fade += (1.0f - fade) * 0.18f;
        geom();
        pollBindKey();

        int accent = ModuleManager.accent();
        int accentArgb = 0xFF000000 | accent;

        // window
        rrect(g, wx, wy, ww, wh, fa(0xE0101018));
        g.fill(wx, wy, wx + SIDE, wy + wh, fa(0xF00B0B12));
        gradBar(g, wx, wy, ww, 2, accent, PURPLE);
        g.drawString(this.font, HudClient.NAME + " " + HudClient.VERSION, wx + 8, wy + 8, fa(accentArgb), true);

        // sidebar
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int x = wx + 4;
            int y = wy + HDR + 4 + i * 22;
            int w = SIDE - 8;
            boolean hover = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + 20;
            float[] a = catAnim.computeIfAbsent(cats[i], k -> new float[2]);
            a[0] += ((cats[i] == cat ? 1f : 0f) - a[0]) * 0.25f;
            a[1] += ((hover ? 1f : 0f) - a[1]) * 0.25f;
            int bg = lerp(0x00000000, 0x40FFFFFF, Math.max(a[0], a[1] * 0.6f));
            rrect(g, x, y, w, 20, fa(bg));
            if (a[0] > 0.02f) {
                g.fill(x, y + 3, x + 2, y + 17, fa(lerp(0x00000000, accentArgb, a[0])));
            }
            g.drawString(this.font, cats[i].label, x + 8, y + 6, fa(lerp(0xFF888888, 0xFFFFFFFF, Math.max(a[0], a[1]))), true);
        }
        int helpY = wy + wh - 4 - this.font.lineHeight * 4;
        g.drawString(this.font, "L: ac/kapat", wx + 6, helpY, fa(0xFF666666), false);
        g.drawString(this.font, "R: ayarlar", wx + 6, helpY + this.font.lineHeight, fa(0xFF666666), false);
        g.drawString(this.font, "M: tus ata", wx + 6, helpY + this.font.lineHeight * 2, fa(0xFF666666), false);

        if (open == null) {
            drawCards(g, mouseX, mouseY, accent, accentArgb);
        } else {
            drawSettings(g, mouseX, mouseY, accent, accentArgb);
        }
    }

    private void drawCards(GuiGraphics g, int mouseX, int mouseY, int accent, int accentArgb) {
        g.drawString(this.font, cat.label, cx() + 8, wy + 8, fa(0xFFAAAAAA), true);
        List<Module> mods = modulesOf(cat);
        for (int i = 0; i < mods.size(); i++) {
            Module m = mods.get(i);
            int x = cardX(i);
            int y = cardY(i);
            int w = cardW();
            boolean hover = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + CARD_H;
            float[] a = anim.computeIfAbsent(m, k -> new float[]{m.isEnabled() ? 1f : 0f, 0f});
            a[0] += ((m.isEnabled() ? 1f : 0f) - a[0]) * 0.25f;
            a[1] += ((hover ? 1f : 0f) - a[1]) * 0.25f;

            rrect(g, x, y, w, CARD_H, fa(lerp(0xC0181822, 0xD02A2A3C, a[1])));
            if (a[0] > 0.02f) {
                g.fill(x, y + 2, x + 2, y + CARD_H - 2, fa(lerp(0x00000000, accentArgb, a[0])));
            }
            g.drawString(this.font, m.getName(), x + 8, y + 4, fa(lerp(0xFFBBBBBB, 0xFFFFFFFF, a[0])), true);

            String sub;
            if (binding == m) {
                sub = "tusa bas...";
            } else if (m.getKey() >= 0) {
                sub = "[" + keyName(m.getKey()) + "]";
            } else if (!m.getSettings().isEmpty()) {
                sub = m.getSettings().size() + " ayar";
            } else {
                sub = "";
            }
            if (!sub.isEmpty()) {
                g.drawString(this.font, sub, x + 8, y + 14, fa(0xFF707080), false);
            }

            // switch
            int sw = 22;
            int sh = 10;
            int sx = x + w - sw - 8;
            int sy = y + (CARD_H - sh) / 2;
            rrect(g, sx, sy, sw, sh, fa(lerp(0xFF3A3A48, accentArgb, a[0])));
            int kx = sx + 2 + (int) ((sw - sh) * a[0]);
            g.fill(kx, sy + 2, kx + sh - 4, sy + sh - 2, fa(0xFFFFFFFF));
        }
    }

    private void drawSettings(GuiGraphics g, int mouseX, int mouseY, int accent, int accentArgb) {
        settingsLayout();
        // header with back arrow
        boolean backHover = mouseX >= cx() + 6 && mouseX < cx() + 40 && mouseY >= wy + 4 && mouseY < wy + 18;
        g.drawString(this.font, "< geri", cx() + 8, wy + 8, fa(backHover ? 0xFFFFFFFF : 0xFFAAAAAA), true);
        g.drawString(this.font, open.getName(), cx() + 56, wy + 8, fa(accentArgb), true);

        List<Setting<?>> list = open.getSettings();
        for (int i = 0; i < list.size(); i++) {
            Setting<?> s = list.get(i);
            int x = rowX(i);
            int y = rowY(i);
            int w = setW;
            boolean hover = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + ROW;
            rrect(g, x, y, w, ROW - 1, fa(hover ? 0x70202030 : 0x50000000));

            if (s instanceof BoolSetting b) {
                g.drawString(this.font, b.name, x + 5, y + 3, fa(0xFFFFFFFF), false);
                int sw = 18;
                int sx = x + w - sw - 4;
                rrect(g, sx, y + 3, sw, 8, fa(b.get() ? accentArgb : 0xFF3A3A48));
                int kx = b.get() ? sx + sw - 8 : sx + 1;
                g.fill(kx, y + 4, kx + 7, y + 10, fa(0xFFFFFFFF));
            } else if (s instanceof NumberSetting n) {
                int fillW = (int) Math.round(n.fraction() * w);
                if (fillW > 0) {
                    rrect(g, x, y, Math.max(2, fillW), ROW - 1, fa((accentArgb & 0x00FFFFFF) | 0x70000000));
                }
                g.drawString(this.font, n.name + ": " + n.display(), x + 5, y + 3, fa(0xFFFFFFFF), false);
                if (n.preview != null) {
                    g.fill(x + w - 13, y + 2, x + w - 3, y + ROW - 3, 0xFF000000 | n.preview.rgb());
                }
            } else if (s instanceof ModeSetting m) {
                g.drawString(this.font, m.name, x + 5, y + 3, fa(0xFFFFFFFF), false);
                String t = "< " + m.get() + " >";
                g.drawString(this.font, t, x + w - 5 - this.font.width(t), y + 3, fa(accentArgb), false);
            } else if (s instanceof TextSetting t) {
                g.drawString(this.font, t.name + ": " + t.get(), x + 5, y + 3, fa(0xFFAAAAAA), false);
            } else if (s instanceof ListSetting l) {
                g.drawString(this.font, l.name + ": " + l.get().size() + " blok", x + 5, y + 3, fa(0xFFAAAAAA), false);
            } else {
                g.drawString(this.font, s.name, x + 5, y + 3, fa(0xFFFFFFFF), false);
            }
        }
    }

    // ------------------------------------------------------------------ key binding (polls GLFW like ModuleManager does)

    private void pollBindKey() {
        if (binding == null) {
            return;
        }
        long window = GLFW.glfwGetCurrentContext();
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            if (GLFW.glfwGetKey(window, k) == GLFW.GLFW_PRESS) {
                binding.setKey(k == GLFW.GLFW_KEY_ESCAPE ? -1 : k);
                binding = null;
                return;
            }
        }
    }

    // ------------------------------------------------------------------ mouse

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x();
        double my = event.y();
        int button = event.button();
        geom();

        if (open != null) {
            settingsLayout();
            if (button == 1 || (mx >= cx() + 6 && mx < cx() + 40 && my >= wy + 4 && my < wy + 18)) {
                open = null;
                Config.save();
                return true;
            }
            List<Setting<?>> list = open.getSettings();
            for (int i = 0; i < list.size(); i++) {
                int x = rowX(i);
                int y = rowY(i);
                if (mx < x || mx >= x + setW || my < y || my >= y + ROW) {
                    continue;
                }
                Setting<?> s = list.get(i);
                if (s instanceof BoolSetting b) {
                    b.toggle();
                } else if (s instanceof NumberSetting n) {
                    dragging = n;
                    dragX0 = x;
                    dragX1 = x + setW;
                    n.setFromFraction((mx - x) / (double) setW);
                } else if (s instanceof ModeSetting m) {
                    if (button == 1) {
                        m.prev();
                    } else {
                        m.next();
                    }
                }
                return true;
            }
            return true;
        }

        // sidebar
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int x = wx + 4;
            int y = wy + HDR + 4 + i * 22;
            if (mx >= x && mx < x + SIDE - 8 && my >= y && my < y + 20) {
                cat = cats[i];
                return true;
            }
        }

        // module cards
        List<Module> mods = modulesOf(cat);
        for (int i = 0; i < mods.size(); i++) {
            int x = cardX(i);
            int y = cardY(i);
            if (mx >= x && mx < x + cardW() && my >= y && my < y + CARD_H) {
                Module m = mods.get(i);
                if (button == 0) {
                    m.toggle();
                    Config.save();
                } else if (button == 1) {
                    if (!m.getSettings().isEmpty()) {
                        open = m;
                    }
                } else if (button == 2) {
                    binding = m;
                }
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragXAmount, double dragYAmount) {
        if (dragging != null) {
            dragging.setFromFraction((event.x() - dragX0) / (double) (dragX1 - dragX0));
            return true;
        }
        return super.mouseDragged(event, dragXAmount, dragYAmount);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (dragging != null) {
            dragging = null;
            Config.save();
            return true;
        }
        return super.mouseReleased(event);
    }
}
