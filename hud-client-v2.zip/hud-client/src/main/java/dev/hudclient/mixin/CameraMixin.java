package dev.hudclient.mixin;

import dev.hudclient.util.CameraControl;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Moves/rotates the camera for Freecam and Freelook (no wall collision, so you can look through walls). */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow
    protected abstract void setRotation(float yRot, float xRot);

    @Shadow
    protected abstract void setPosition(double x, double y, double z);

    @Inject(method = "setup", at = @At("RETURN"))
    private void hud$setup(CallbackInfo ci) {
        if (!CameraControl.active()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return;
        }
        float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        setRotation(CameraControl.yaw, CameraControl.pitch);

        if (CameraControl.freecam) {
            setPosition(
                    CameraControl.px + (CameraControl.x - CameraControl.px) * pt,
                    CameraControl.py + (CameraControl.y - CameraControl.py) * pt,
                    CameraControl.pz + (CameraControl.z - CameraControl.pz) * pt);
        } else {
            double yr = Math.toRadians(CameraControl.yaw);
            double xr = Math.toRadians(CameraControl.pitch);
            double dx = -Math.sin(yr) * Math.cos(xr);
            double dy = -Math.sin(xr);
            double dz = Math.cos(yr) * Math.cos(xr);
            Vec3 eye = mc.player.getEyePosition(pt);
            double d = CameraControl.distance;
            setPosition(eye.x - dx * d, eye.y - dy * d, eye.z - dz * d);
        }
    }
}
