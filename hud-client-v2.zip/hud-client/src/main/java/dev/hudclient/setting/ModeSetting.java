package dev.hudclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.Arrays;

public class ModeSetting extends Setting<String> {
    public final String[] modes;
    private int index;

    public ModeSetting(String name, String def, String... modes) {
        super(name, def);
        this.modes = modes;
        this.index = Math.max(0, Arrays.asList(modes).indexOf(def));
        this.value = modes[this.index];
    }

    public void next() {
        index = (index + 1) % modes.length;
        value = modes[index];
    }

    public void prev() {
        index = (index - 1 + modes.length) % modes.length;
        value = modes[index];
    }

    public boolean is(String mode) {
        return value.equals(mode);
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(value);
    }

    @Override
    public void load(JsonElement element) {
        if (element != null && element.isJsonPrimitive()) {
            int i = Arrays.asList(modes).indexOf(element.getAsString());
            if (i >= 0) {
                index = i;
                value = modes[i];
            }
        }
    }
}
