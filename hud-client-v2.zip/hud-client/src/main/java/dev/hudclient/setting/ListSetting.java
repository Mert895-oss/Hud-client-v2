package dev.hudclient.setting;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.ArrayList;
import java.util.List;

/** A list of strings (for example block ids). Edited with chat commands. */
public class ListSetting extends Setting<List<String>> {
    /** Increases on every change so modules can notice edits. */
    public int version;

    public ListSetting(String name, List<String> def) {
        super(name, new ArrayList<>(def));
    }

    public boolean add(String s) {
        if (value.contains(s)) {
            return false;
        }
        value.add(s);
        version++;
        return true;
    }

    public boolean remove(String s) {
        boolean r = value.remove(s);
        if (r) {
            version++;
        }
        return r;
    }

    public void clear() {
        value.clear();
        version++;
    }

    @Override
    public JsonElement save() {
        JsonArray a = new JsonArray();
        for (String s : value) {
            a.add(new JsonPrimitive(s));
        }
        return a;
    }

    @Override
    public void load(JsonElement element) {
        if (element != null && element.isJsonArray()) {
            value.clear();
            for (JsonElement e : element.getAsJsonArray()) {
                if (e.isJsonPrimitive()) {
                    value.add(e.getAsString());
                }
            }
            version++;
        }
    }
}
