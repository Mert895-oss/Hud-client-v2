package dev.hudclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.Locale;

public class NumberSetting extends Setting<Double> {
    public final double min;
    public final double max;
    public final double step;
    /** Set on the "R" slider of a color so the GUI can draw a preview swatch. */
    public ColorSetting preview;

    public NumberSetting(String name, double def, double min, double max, double step) {
        super(name, def);
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public double getD() {
        return value;
    }

    public int getInt() {
        return (int) Math.round(value);
    }

    @Override
    public void set(Double v) {
        value = snap(v);
    }

    public void setFromFraction(double f) {
        double c = Math.max(0.0, Math.min(1.0, f));
        value = snap(min + (max - min) * c);
    }

    public double fraction() {
        return (value - min) / (max - min);
    }

    private double snap(double v) {
        if (step > 0) {
            v = Math.round((v - min) / step) * step + min;
        }
        return Math.max(min, Math.min(max, v));
    }

    public String display() {
        if (step >= 1) {
            return Integer.toString((int) Math.round(value));
        }
        return String.format(Locale.ROOT, step < 0.01 ? "%.3f" : "%.2f", value);
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(value);
    }

    @Override
    public void load(JsonElement element) {
        if (element != null && element.isJsonPrimitive()) {
            value = snap(element.getAsDouble());
        }
    }
}
