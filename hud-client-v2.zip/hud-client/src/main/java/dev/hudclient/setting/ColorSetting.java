package dev.hudclient.setting;

/** A color is three number sliders (R, G, B) that the module registers as normal settings. */
public class ColorSetting {
    public final NumberSetting r;
    public final NumberSetting g;
    public final NumberSetting b;

    public ColorSetting(String name, int red, int green, int blue) {
        r = new NumberSetting(name + " R", red, 0, 255, 1);
        g = new NumberSetting(name + " G", green, 0, 255, 1);
        b = new NumberSetting(name + " B", blue, 0, 255, 1);
        r.preview = this;
    }

    public int rgb() {
        return (r.getInt() << 16) | (g.getInt() << 8) | b.getInt();
    }

    public int argb(int alpha) {
        return ((alpha & 255) << 24) | rgb();
    }
}
