package dev.hudclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/** A text value. Edited with chat commands (the GUI only shows it). */
public class TextSetting extends Setting<String> {
    public TextSetting(String name, String def) {
        super(name, def);
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(value);
    }

    @Override
    public void load(JsonElement element) {
        if (element != null && element.isJsonPrimitive()) {
            value = element.getAsString();
        }
    }
}
