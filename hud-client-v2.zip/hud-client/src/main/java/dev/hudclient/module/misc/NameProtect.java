package dev.hudclient.module.misc;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.module.ModuleManager;
import dev.hudclient.setting.TextSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;

import java.util.Optional;

/** Replaces your own name with a fake one in chat and in this client's name tags. Change it with /nameprotect. */
public class NameProtect extends Module {
    public final TextSetting fakeName = text("Fake Name (/nameprotect)", "Protected");

    public NameProtect() {
        super("NameProtect", Category.MISC);
    }

    private static NameProtect instance() {
        NameProtect m = ModuleManager.get(NameProtect.class);
        return m != null && m.isEnabled() ? m : null;
    }

    private static String realName() {
        Minecraft mc = Minecraft.getInstance();
        return mc.player == null ? null : mc.player.getName().getString();
    }

    /** For plain strings (name tags etc.). */
    public static String apply(String text) {
        NameProtect m = instance();
        String real = realName();
        if (m == null || real == null || real.isEmpty()) {
            return text;
        }
        return text.replace(real, m.fakeName.get());
    }

    public static Component modify(Component message) {
        NameProtect m = instance();
        String real = realName();
        if (m == null || real == null || real.isEmpty() || !message.getString().contains(real)) {
            return message;
        }
        String fake = m.fakeName.get();
        MutableComponent out = Component.empty();
        message.<Object>visit((style, text) -> {
            out.append(Component.literal(text.replace(real, fake)).withStyle(style));
            return Optional.empty();
        }, Style.EMPTY);
        return out;
    }

    /** Chat hook: returns false to hide the original message (we show the edited copy ourselves). */
    public static boolean onChat(Component message) {
        Component edited = modify(message);
        if (edited == message) {
            return true;
        }
        Minecraft.getInstance().gui.getChat().addMessage(edited);
        return false;
    }
}
