package dev.hudclient.module.render;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.render.Render3D;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.ColorSetting;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

public class PearlPredict extends Module {
    private final ColorSetting color = color("Color", 80, 220, 255);
    private final NumberSetting width = num("Line Width", 0.04, 0.01, 0.2, 0.005);
    private final BoolSetting blockBox = bool("Highlight Landing Block", true);
    private final NumberSetting fillAlpha = num("Block Fill Alpha", 70, 0, 255, 1);
    private final NumberSetting maxTicks = num("Max Ticks", 150, 20, 400, 10);

    public PearlPredict() {
        super("PearlPredict", Category.RENDER);
    }

    @Override
    public void onRender3D() {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) {
            return;
        }
        if (!p.getMainHandItem().is(Items.ENDER_PEARL) && !p.getOffhandItem().is(Items.ENDER_PEARL)) {
            return;
        }

        float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        double xr = Math.toRadians(p.getViewXRot(pt));
        double yr = Math.toRadians(p.getViewYRot(pt));

        // same launch math as vanilla: speed 1.5, plus the thrower's own movement
        Vec3 dir = new Vec3(-Math.sin(yr) * Math.cos(xr), -Math.sin(xr), Math.cos(yr) * Math.cos(xr)).normalize();
        Vec3 vel = dir.scale(1.5);
        Vec3 pm = p.getDeltaMovement();
        vel = vel.add(pm.x, p.onGround() ? 0.0 : pm.y, pm.z);

        Vec3 eye = p.getEyePosition(pt);
        Vec3 pos = new Vec3(eye.x, eye.y - 0.1, eye.z);

        List<Vec3> points = new ArrayList<>();
        points.add(pos);
        BlockHitResult landing = null;

        for (int i = 0; i < maxTicks.getInt(); i++) {
            Vec3 next = pos.add(vel);
            BlockHitResult result = mc.level.clip(new ClipContext(pos, next, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
            if (result.getType() != HitResult.Type.MISS) {
                points.add(result.getLocation());
                landing = result;
                break;
            }
            pos = next;
            points.add(pos);
            vel = vel.scale(0.99).add(0.0, -0.03, 0.0);
            if (pos.y < -100.0) {
                break;
            }
        }

        int lineColor = color.argb(230);
        for (int i = 1; i < points.size(); i++) {
            Render3D.line(points.get(i - 1), points.get(i), width.getD(), lineColor);
        }

        if (landing != null && blockBox.get()) {
            BlockPos bp = landing.getBlockPos();
            AABB box = new AABB(bp).inflate(0.002);
            Render3D.box(box, color.argb(fillAlpha.getInt()));
            Render3D.outline(box, width.getD(), lineColor);
        }
    }
}
