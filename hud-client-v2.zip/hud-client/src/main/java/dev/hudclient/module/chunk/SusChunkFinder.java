package dev.hudclient.module.chunk;

import dev.hudclient.setting.BoolSetting;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;

import java.util.HashSet;
import java.util.Set;

/** Marks chunks that contain amethyst, vines, cave vines, kelp or mobs (any one is enough). */
public class SusChunkFinder extends ChunkFinder {
    private final BoolSetting amethyst = bool("Amethyst", true);
    private final BoolSetting vines = bool("Vines", true);
    private final BoolSetting caveVines = bool("Cave Vines", true);
    private final BoolSetting kelp = bool("Kelp", true);
    private final BoolSetting mobs = bool("Mobs", true);

    private final Set<Long> mobChunks = new HashSet<>();

    public SusChunkFinder() {
        super("SusChunkFinder", 255, 200, 0);
    }

    @Override
    protected void preScan() {
        mobChunks.clear();
        if (!mobs.get() || mc.level == null) {
            return;
        }
        for (Entity e : mc.level.entitiesForRendering()) {
            if (e instanceof Mob && e.isAlive()) {
                mobChunks.add(key(e.getBlockX() >> 4, e.getBlockZ() >> 4));
            }
        }
    }

    @Override
    protected boolean matches(LevelChunk chunk, int cx, int cz) {
        if (mobs.get() && mobChunks.contains(key(cx, cz))) {
            return true;
        }
        for (LevelChunkSection section : chunk.getSections()) {
            if (section.hasOnlyAir()) {
                continue;
            }
            if (section.maybeHas(this::isTarget)) {
                return true;
            }
        }
        return false;
    }

    private boolean isTarget(BlockState s) {
        if (amethyst.get() && (s.is(Blocks.AMETHYST_CLUSTER) || s.is(Blocks.BUDDING_AMETHYST)
                || s.is(Blocks.AMETHYST_BLOCK) || s.is(Blocks.LARGE_AMETHYST_BUD)
                || s.is(Blocks.MEDIUM_AMETHYST_BUD) || s.is(Blocks.SMALL_AMETHYST_BUD))) {
            return true;
        }
        if (vines.get() && s.is(Blocks.VINE)) {
            return true;
        }
        if (caveVines.get() && (s.is(Blocks.CAVE_VINES) || s.is(Blocks.CAVE_VINES_PLANT))) {
            return true;
        }
        return kelp.get() && (s.is(Blocks.KELP) || s.is(Blocks.KELP_PLANT));
    }
}
