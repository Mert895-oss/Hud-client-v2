package dev.hudclient.module.movement;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.setting.NumberSetting;
import dev.hudclient.util.CameraControl;

/** Look around with the mouse without turning your character. The camera ignores walls. */
public class Freelook extends Module {
    private final NumberSetting distance = num("Distance", 4.0, 1.0, 30.0, 0.5);

    public Freelook() {
        super("Freelook", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        if (mc.player == null) {
            setEnabled(false);
            return;
        }
        CameraControl.distance = distance.getD();
        CameraControl.start(mc, false);
    }

    @Override
    public void onDisable() {
        CameraControl.stop(mc, false);
    }

    @Override
    public void onTick() {
        CameraControl.distance = distance.getD();
    }
}
