package dev.hudclient.module.chunk;

import dev.hudclient.setting.NumberSetting;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.status.ChunkStatus;

import java.util.ArrayDeque;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Scans loaded chunks a few per tick and remembers which ones match.
 * Subclasses decide what "matches" means.
 */
public abstract class ChunkFinder extends ChunkMarker {
    protected final NumberSetting radius = num("Scan Radius", 16, 2, 32, 1);
    protected final NumberSetting speed = num("Chunks Per Tick", 40, 5, 200, 5);

    private final Map<Long, int[]> found = new HashMap<>();
    private final ArrayDeque<int[]> queue = new ArrayDeque<>();
    private int timer;

    protected ChunkFinder(String name, int r, int g, int b) {
        super(name, r, g, b);
    }

    public static long key(int cx, int cz) {
        return ((long) cx & 0xFFFFFFFFL) | (((long) cz & 0xFFFFFFFFL) << 32);
    }

    /** Called before every new scan cycle. */
    protected void preScan() {
    }

    protected abstract boolean matches(LevelChunk chunk, int cx, int cz);

    @Override
    protected Collection<int[]> chunks() {
        return found.values();
    }

    @Override
    public void onDisable() {
        found.clear();
        queue.clear();
        timer = 0;
    }

    @Override
    public void onTick() {
        ClientLevel level = mc.level;
        LocalPlayer p = mc.player;
        if (level == null || p == null) {
            return;
        }
        int pcx = p.getBlockX() >> 4;
        int pcz = p.getBlockZ() >> 4;
        int r = radius.getInt();

        if (timer-- <= 0) {
            timer = 40;
            preScan();
            queue.clear();
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    queue.add(new int[]{pcx + dx, pcz + dz});
                }
            }
            Iterator<int[]> it = found.values().iterator();
            while (it.hasNext()) {
                int[] c = it.next();
                if (Math.abs(c[0] - pcx) > r + 2 || Math.abs(c[1] - pcz) > r + 2) {
                    it.remove();
                }
            }
        }

        int budget = speed.getInt();
        while (budget-- > 0 && !queue.isEmpty()) {
            int[] c = queue.poll();
            long k = key(c[0], c[1]);
            ChunkAccess access = level.getChunk(c[0], c[1], ChunkStatus.FULL, false);
            if (access instanceof LevelChunk && matches((LevelChunk) access, c[0], c[1])) {
                found.put(k, c);
            } else {
                found.remove(k);
            }
        }
    }
}
