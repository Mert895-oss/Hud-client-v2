package dev.hudclient.module.hud;

import dev.hudclient.HudClient;
import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.module.ModuleManager;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.ColorSetting;
import dev.hudclient.setting.ModeSetting;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** The on-screen overlay: watermark, FPS, coordinates, speed, radar and the enabled-module list. */
public class HudModule extends Module {
    public final ColorSetting color = color("Color", 85, 255, 255);
    private final ModeSetting font = mode("Font", "Default", "Default", "Uniform", "Alt", "Illager");
    private final BoolSetting watermark = bool("Watermark", true);
    private final BoolSetting fps = bool("FPS", true);
    private final BoolSetting coords = bool("Coordinates", true);
    private final BoolSetting otherDim = bool("Nether/Overworld Coords", true);
    private final BoolSetting speed = bool("Speed", true);
    private final BoolSetting moduleList = bool("Module List", true);
    private final BoolSetting radar = bool("Radar", true);
    private final NumberSetting radarSize = num("Radar Size", 90, 50, 200, 5);
    private final NumberSetting radarRange = num("Radar Range", 40, 10, 128, 2);
    private final BoolSetting radarMobs = bool("Radar Mobs", false);

    public HudModule() {
        super("HUD", Category.HUD);
        setEnabled(true);
    }

    private int frames;
    private int fpsValue;
    private long fpsStamp = System.currentTimeMillis();

    /** Own frame counter so we do not depend on a Minecraft fps accessor. */
    private int currentFps() {
        frames++;
        long now = System.currentTimeMillis();
        if (now - fpsStamp >= 1000L) {
            fpsValue = frames;
            frames = 0;
            fpsStamp = now;
        }
        return fpsValue;
    }

    private Style style() {
        String f = font.get();
        String path;
        if (f.equals("Uniform")) {
            path = "uniform";
        } else if (f.equals("Alt")) {
            path = "alt";
        } else if (f.equals("Illager")) {
            path = "illageralt";
        } else {
            return Style.EMPTY;
        }
        return Style.EMPTY.withFont(new FontDescription.Resource(Identifier.withDefaultNamespace(path)));
    }

    private Component comp(String text, Style style) {
        return Component.literal(text).withStyle(style);
    }

    @Override
    public void onRenderHud(GuiGraphics g) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) {
            return;
        }
        Style style = style();
        int col = 0xFF000000 | color.rgb();
        int lh = mc.font.lineHeight + 2;
        int x = 4;
        int y = 4;

        if (watermark.get()) {
            g.drawString(mc.font, comp(HudClient.NAME + " " + HudClient.VERSION, style), x, y, col, true);
            y += lh;
        }
        if (fps.get()) {
            g.drawString(mc.font, comp("FPS: " + currentFps(), style), x, y, col, true);
            y += lh;
        }
        if (coords.get()) {
            String pos = String.format(Locale.ROOT, "XYZ: %.1f / %.1f / %.1f", p.getX(), p.getY(), p.getZ());
            g.drawString(mc.font, comp(pos, style), x, y, col, true);
            y += lh;
            if (otherDim.get()) {
                boolean nether = mc.level.dimension() == Level.NETHER;
                String other;
                if (nether) {
                    other = String.format(Locale.ROOT, "Overworld: %.0f / %.0f", p.getX() * 8.0, p.getZ() * 8.0);
                } else {
                    other = String.format(Locale.ROOT, "Nether: %.0f / %.0f", p.getX() / 8.0, p.getZ() / 8.0);
                }
                g.drawString(mc.font, comp(other, style), x, y, col, true);
                y += lh;
            }
        }
        if (speed.get()) {
            double dx = p.getX() - p.xo;
            double dz = p.getZ() - p.zo;
            String s = String.format(Locale.ROOT, "Speed: %.2f b/s", Math.sqrt(dx * dx + dz * dz) * 20.0);
            g.drawString(mc.font, comp(s, style), x, y, col, true);
            y += lh;
        }

        if (moduleList.get()) {
            drawModuleList(g, style, col, lh);
        }
        if (radar.get()) {
            drawRadar(g, p, col);
        }
    }

    private void drawModuleList(GuiGraphics g, Style style, int col, int lh) {
        List<Module> active = new ArrayList<>();
        for (Module m : ModuleManager.all()) {
            if (m.isEnabled() && m != this) {
                active.add(m);
            }
        }
        active.sort(Comparator.comparingInt((Module m) -> -mc.font.width(comp(m.getName(), style))));
        int screenW = mc.getWindow().getGuiScaledWidth();
        int y = 4;
        for (Module m : active) {
            Component c = comp(m.getName(), style);
            int w = mc.font.width(c);
            g.drawString(mc.font, c, screenW - w - 4, y, col, true);
            y += lh;
        }
    }

    private void drawRadar(GuiGraphics g, LocalPlayer p, int col) {
        int size = radarSize.getInt();
        int rx = 6;
        int ry = mc.getWindow().getGuiScaledHeight() - size - 6;
        int cx = rx + size / 2;
        int cy = ry + size / 2;
        double half = size / 2.0 - 2.0;
        double scale = half / radarRange.getD();

        g.fill(rx, ry, rx + size, ry + size, 0x90000000);
        g.fill(rx, ry, rx + size, ry + 1, col);
        g.fill(rx, ry + size - 1, rx + size, ry + size, col);
        g.fill(rx, ry, rx + 1, ry + size, col);
        g.fill(rx + size - 1, ry, rx + size, ry + size, col);
        g.fill(cx, ry + 1, cx + 1, ry + size - 1, 0x33FFFFFF);
        g.fill(rx + 1, cy, rx + size - 1, cy + 1, 0x33FFFFFF);

        double yaw = Math.toRadians(p.getYRot());
        double sin = Math.sin(yaw);
        double cos = Math.cos(yaw);

        for (Entity e : mc.level.entitiesForRendering()) {
            if (e == p) {
                continue;
            }
            int dot;
            if (e instanceof Player) {
                dot = 0xFFFF4040;
            } else if (radarMobs.get() && e instanceof Mob) {
                dot = e instanceof Enemy ? 0xFFFFA040 : 0xFF40FF40;
            } else {
                continue;
            }
            double dx = e.getX() - p.getX();
            double dz = e.getZ() - p.getZ();
            double forward = dx * -sin + dz * cos;
            double right = dx * -cos + dz * -sin;
            double sx = right * scale;
            double sy = forward * scale;
            if (Math.abs(sx) > half || Math.abs(sy) > half) {
                continue;
            }
            int px = (int) Math.round(cx + sx);
            int py = (int) Math.round(cy - sy);
            g.fill(px - 1, py - 1, px + 2, py + 2, dot);
        }

        // you
        g.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFFFFFF);
    }
}
