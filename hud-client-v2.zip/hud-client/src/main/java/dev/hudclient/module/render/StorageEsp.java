package dev.hudclient.module.render;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.render.Render3D;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.DispenserBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.block.entity.TrappedChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.ArrayList;
import java.util.List;

public class StorageEsp extends Module {
    private final BoolSetting chests = bool("Chests", true);
    private final BoolSetting trapped = bool("Trapped Chests", true);
    private final BoolSetting ender = bool("Ender Chests", true);
    private final BoolSetting barrels = bool("Barrels", true);
    private final BoolSetting shulkers = bool("Shulkers", true);
    private final BoolSetting others = bool("Hoppers/Furnaces/Dispensers", false);
    private final BoolSetting fill = bool("Fill", true);
    private final NumberSetting fillAlpha = num("Fill Alpha", 40, 0, 255, 1);
    private final BoolSetting outline = bool("Outline", true);
    private final NumberSetting width = num("Line Width", 0.03, 0.005, 0.15, 0.005);
    private final BoolSetting tracers = bool("Tracers", true);
    private final NumberSetting range = num("Range", 96, 16, 256, 8);

    private static final class Entry {
        final AABB box;
        final int rgb;

        Entry(AABB box, int rgb) {
            this.box = box;
            this.rgb = rgb;
        }
    }

    private List<Entry> entries = new ArrayList<>();
    private int timer;

    public StorageEsp() {
        super("StorageESP", Category.RENDER);
    }

    @Override
    public void onEnable() {
        timer = 0;
    }

    @Override
    public void onTick() {
        if (timer-- > 0) {
            return;
        }
        timer = 10;
        rebuild();
    }

    private void rebuild() {
        ClientLevel level = mc.level;
        LocalPlayer p = mc.player;
        if (level == null || p == null) {
            return;
        }
        List<Entry> list = new ArrayList<>();
        int cr = (int) Math.ceil(range.getD() / 16.0) + 1;
        int pcx = p.getBlockX() >> 4;
        int pcz = p.getBlockZ() >> 4;
        double range2 = range.getD() * range.getD();

        for (int dx = -cr; dx <= cr; dx++) {
            for (int dz = -cr; dz <= cr; dz++) {
                ChunkAccess access = level.getChunk(pcx + dx, pcz + dz, ChunkStatus.FULL, false);
                if (!(access instanceof LevelChunk)) {
                    continue;
                }
                LevelChunk chunk = (LevelChunk) access;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    int rgb = colorFor(be);
                    if (rgb < 0) {
                        continue;
                    }
                    BlockPos pos = be.getBlockPos();
                    if (p.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > range2) {
                        continue;
                    }
                    BlockState state = level.getBlockState(pos);
                    VoxelShape shape = state.getShape(level, pos);
                    AABB box = shape.isEmpty() ? new AABB(pos) : shape.bounds().move(pos);
                    list.add(new Entry(box, rgb));
                }
            }
        }
        entries = list;
    }

    /** Returns RGB or -1 if this block entity should not be shown. */
    private int colorFor(BlockEntity be) {
        if (be instanceof TrappedChestBlockEntity) {
            return trapped.get() ? 0xFF3030 : -1;
        }
        if (be instanceof ChestBlockEntity) {
            return chests.get() ? 0xFFA500 : -1;
        }
        if (be instanceof EnderChestBlockEntity) {
            return ender.get() ? 0xA040FF : -1;
        }
        if (be instanceof BarrelBlockEntity) {
            return barrels.get() ? 0xB07040 : -1;
        }
        if (be instanceof ShulkerBoxBlockEntity) {
            return shulkers.get() ? 0xFF60C0 : -1;
        }
        if (be instanceof HopperBlockEntity || be instanceof AbstractFurnaceBlockEntity || be instanceof DispenserBlockEntity) {
            return others.get() ? 0xA0A0A0 : -1;
        }
        return -1;
    }

    @Override
    public void onRender3D() {
        int fa = fillAlpha.getInt();
        Vec3 from = tracers.get() ? Render3D.tracerOrigin() : null;
        for (Entry e : entries) {
            if (fill.get()) {
                Render3D.box(e.box, (fa << 24) | e.rgb);
            }
            if (outline.get()) {
                Render3D.outline(e.box, width.getD(), 0xE6000000 | e.rgb);
            }
            if (from != null) {
                Render3D.line(from, e.box.getCenter(), width.getD(), 0xE6000000 | e.rgb);
            }
        }
    }
}
