package dev.hudclient.module.misc;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.module.ModuleManager;
import dev.hudclient.setting.ModeSetting;
import dev.hudclient.setting.TextSetting;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Copies another player's skin onto yourself (client side, only you see it).
 * Enable it while looking at a player, or use /skinsteal NAME.
 */
public class SkinStealer extends Module {
    private final ModeSetting source = mode("Source", "Crosshair", "Crosshair", "Nearest");
    public final TextSetting target = text("Target (/skinsteal)", "");

    private static Object stolen;

    public SkinStealer() {
        super("SkinStealer", Category.MISC);
    }

    /** Called from the player mixin. */
    public static Object stolenFor(Object self) {
        if (stolen == null) {
            return null;
        }
        SkinStealer m = ModuleManager.get(SkinStealer.class);
        if (m == null || !m.isEnabled()) {
            return null;
        }
        return self == net.minecraft.client.Minecraft.getInstance().player ? stolen : null;
    }

    @Override
    public void onEnable() {
        steal();
    }

    @Override
    public void onDisable() {
        stolen = null;
    }

    /** Sets the target name and steals right away (used by the command). */
    public boolean stealFrom(String name) {
        target.set(name);
        if (!isEnabled()) {
            setEnabled(true);
            return stolen != null;
        }
        steal();
        return stolen != null;
    }

    private void steal() {
        stolen = null;
        if (mc.level == null || mc.player == null) {
            return;
        }
        AbstractClientPlayer found = null;
        String name = target.get();
        if (name != null && !name.isEmpty()) {
            for (AbstractClientPlayer p : mc.level.players()) {
                if (p != mc.player && p.getName().getString().equalsIgnoreCase(name)) {
                    found = p;
                    break;
                }
            }
        } else {
            if (source.is("Crosshair")) {
                HitResult hit = mc.hitResult;
                if (hit instanceof EntityHitResult ehr && ehr.getEntity() instanceof AbstractClientPlayer acp && acp != mc.player) {
                    found = acp;
                }
            }
            if (found == null) {
                double best = Double.MAX_VALUE;
                for (AbstractClientPlayer p : mc.level.players()) {
                    if (p == mc.player) {
                        continue;
                    }
                    double d = mc.player.distanceToSqr(p);
                    if (d < best) {
                        best = d;
                        found = p;
                    }
                }
            }
        }
        if (found != null) {
            Object skin = found.getSkin();
            stolen = skin;
        }
    }
}
