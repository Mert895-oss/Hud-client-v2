package dev.hudclient.module;

public enum Category {
    COMBAT("Combat"),
    MOVEMENT("Movement"),
    RENDER("Render"),
    CHUNKS("Chunks"),
    MISC("Misc"),
    HUD("HUD");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
