package dev.hudclient.module.combat;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import net.minecraft.client.player.LocalPlayer;

public class Sprint extends Module {
    public Sprint() {
        super("Sprint", Category.COMBAT);
    }

    @Override
    public void onTick() {
        LocalPlayer p = mc.player;
        if (p == null || mc.screen != null) {
            return;
        }
        if (mc.options.keyUp.isDown() && !p.isShiftKeyDown() && !p.horizontalCollision
                && !p.isUsingItem() && p.getFoodData().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }
}
