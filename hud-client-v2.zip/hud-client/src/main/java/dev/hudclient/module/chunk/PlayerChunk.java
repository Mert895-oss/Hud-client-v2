package dev.hudclient.module.chunk;

import dev.hudclient.setting.NumberSetting;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Marks the chunk of every other player whose Y is below the limit (default 0). */
public class PlayerChunk extends ChunkMarker {
    private final NumberSetting maxY = num("Max Y", 0, -64, 320, 1);
    private List<int[]> found = new ArrayList<>();

    public PlayerChunk() {
        super("PlayerChunk", 255, 80, 80);
    }

    @Override
    protected Collection<int[]> chunks() {
        return found;
    }

    @Override
    public void onTick() {
        ClientLevel level = mc.level;
        LocalPlayer self = mc.player;
        if (level == null || self == null) {
            return;
        }
        List<int[]> list = new ArrayList<>();
        Set<Long> seen = new HashSet<>();
        for (AbstractClientPlayer e : level.players()) {
            if (e == self || e.getY() >= maxY.getD()) {
                continue;
            }
            int cx = e.getBlockX() >> 4;
            int cz = e.getBlockZ() >> 4;
            long key = ChunkFinder.key(cx, cz);
            if (seen.add(key)) {
                list.add(new int[]{cx, cz});
            }
        }
        found = list;
    }
}
